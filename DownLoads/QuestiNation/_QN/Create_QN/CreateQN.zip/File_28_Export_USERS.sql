
delete from USERS;
commit;

insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (1, 'SERGEY', 'SURIKOV', 'sas', 'ssurikov@pd.state.gov', 'A', 0);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (2, 'WILLIAM', 'GOODWIN', 'wg', 'wgoodwin2@pd.state.net', 'A', 0);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (3, 'SANA', 'ABED-KOTOB', 'pass', 'EMAIL', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (4, 'MAGGIE', 'AHERN', 'pass', 'ssurikov@pd.state.gov', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (5, 'WILLIAM', 'ANCKER', 'pass', 'EMAIL', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (6, 'ERIK', 'ANDERSON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (7, 'ALCE', 'ARMITAGE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (8, 'KAREN', 'ASCHAFFEBURG', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (9, 'MARY', 'ASHSLEY', 'pass', 'ssurikov@pd.state.gov', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (10, 'KATRINA', 'ASKEW', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (11, 'ALANNA', 'BAILEY', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (12, 'SUSIE', 'BAKER', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (13, 'LINDA TRESSA', 'BARKER', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (14, 'JOYCE', 'BEAMON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (15, 'BRENT', 'BEEMER', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (16, 'MARGERY', 'BENSON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (17, 'ELLEN', 'BERELSON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (18, 'TERRY', 'BLATT', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (19, 'ORNA', 'BLUM', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (20, 'PEGGY', 'BOND', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (21, 'SUE', 'BORJA', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (22, 'ROBIN', 'BRADLEY', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (23, 'DONNA', 'BRISCOE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (24, 'DANA', 'BULLOCK', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (25, 'DEBORAH', 'BURRELL', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (26, 'MICHAEL', 'CAIN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (27, 'THOMAS', 'CARMICHAEL', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (28, 'WILLIE', 'CARTLEDGE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (29, 'BEN', 'CASTRO', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (30, 'RUTA', 'CHAGNON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (31, 'DEBORAH', 'CHAOMAN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (32, 'JACKIE', 'CHISOLM', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (33, 'ELLA', 'CLEMENT-LILLY', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (34, 'SUSAN', 'COHEN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (35, 'EILEEN', 'CONNOLLY', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (36, 'J ANDREW', 'CORTEZ_GREIG', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (37, 'MARIANNE', 'CRAVEN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (38, 'GAIL', 'CURTIS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (39, 'LORRAINE', 'DALE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (40, 'KAY', 'DAVIS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (41, 'KENDRA', 'DAVIS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (42, 'THOMAS', 'DRISCOLL', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (43, 'LINDA', 'DUNCAN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (44, 'PHYLLIS', 'EASTMAN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (45, 'PAUL', 'ENGLESTAD', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (46, 'DONNA', 'EVERETT', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (47, 'IVEL', 'FELDER', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (48, 'LORRAINE', 'FLORA', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (49, 'AUDREY', 'FORD', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (50, 'AMY', 'FOREST', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (51, 'MARY', 'FRANKO', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (52, 'STEPHEN', 'GANGSTEAD', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (53, 'PATRICIA', 'GARON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (54, 'DEHAB', 'GHEBREAB', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (55, 'JANET', 'GILLIGAN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (56, 'ROY', 'GLOVER', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (57, 'BILL', 'GOODWIN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (58, 'CAROL', 'GRABAUSKAS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (59, 'MIKE', 'GRAHAM', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (60, 'JOCELYN', 'GREENE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (61, 'GAIL', 'GULLIKSEN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (62, 'LAYLA', 'HAKIM', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (63, 'DAVID', 'HAMILL', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (64, 'ILO-MAI', 'HARDING', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (65, 'JOYCE', 'HARROD', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (66, 'KIM', 'HAVENNER', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (67, 'ANDREA', 'HEFLEY', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (68, 'IRVIN', 'HICKS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (69, 'MARK', 'HILBERT', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (70, 'JOCHEN', 'HOFFMAN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (71, 'SHARON', 'HOWARD-JOHNSON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (72, 'CURT', 'HUFF', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (73, 'GAYNELL', 'HUNTER', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (74, 'WILLIAM', 'JAMES', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (75, 'FELITA', 'JENNINGS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (76, 'LUCY', 'JILKA', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (77, 'MARY', 'JOHNSON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (78, 'PATRICIA', 'JOHNSON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (79, 'MARY LOU', 'JOHNSON-PIZARRO', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (80, 'BRENDA', 'JONES', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (81, 'SHALITA', 'JONES', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (82, 'GERRY', 'JORIA', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (83, 'BETSY', 'KAGEN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (84, 'ROBERT', 'KEITH', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (85, 'ANTHONY', 'KLUTTZ', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (86, 'SARAH', 'KNOTT', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (87, 'SUSAN', 'KRAUSE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (88, 'SALLY', 'LAWRENCE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (89, 'DAVID', 'LEVIN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (90, 'CAROLYN', 'LOBRON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (91, 'JOYCE', 'LOVE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (92, 'PAT', 'LUCAS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (93, 'CINDY', 'MALECKI', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (94, 'TIM', 'MARSHALL', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (95, 'ANN', 'MARTIN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (96, 'THERESA', 'MASTRANGELO', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (97, 'ROBERT', 'MCCARTHEY', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (98, 'ANGEL', 'MCLAURINE-QUALLS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (99, 'LORRETTA GENTRY', 'MILBURN', 'pass', 'email', 'A', 2);
commit;
prompt 100 records committed...
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (100, 'LYNN', 'MONTEIRO', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (101, 'ROBIN', 'MOORE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (102, 'DOROTHY', 'MORA', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (103, 'WILLIAM', 'MORGAN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (104, 'PAT', 'MOSLEY', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (105, 'RICHARD', 'MURPHY', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (106, 'ROBIN', 'NEILSON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (107, 'JIM', 'OGUL', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (108, 'APRIL', 'PARKER', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (109, 'BOB', 'PERSIKO', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (110, 'BOBBY', 'PICKETT', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (111, 'HANS', 'POSEY', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (112, 'ANNIE', 'PRINCE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (113, 'LAFAYE', 'PROCTOR', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (114, 'VERONICA', 'RECTOR', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (115, 'VANESSA', 'RELLI-MOREAU', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (116, 'JAY', 'RICHTER', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (117, 'SCOTT', 'RIGHETTI', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (118, 'SEQUITA', 'ROBINSON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (119, 'VICKI', 'ROSE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (120, 'SANDY', 'ROUSE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (121, 'PATRICIA', 'SCHAEFER', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (122, 'HENRY', 'SCOTT', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (123, 'JOHN', 'SEDLINS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (125, 'SHAREN', 'SHEEHAN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (126, 'ALICE', 'SHIFFLETT', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (127, 'DONNA', 'SHIRREFFS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (128, 'GLORIA', 'SIMMS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (129, 'SARAH', 'SMSITH', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (130, 'PATRICIA', 'SPANN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (131, 'KAREN', 'STARKEY', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (132, 'SMAROULA GEORGINA', 'STEPHENS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (133, 'CONNIE', 'STINSON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (134, 'PHYLLIS', 'SWANN-SMITH', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (135, 'RENEE', 'TAFT', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (136, 'LYDIA', 'TAYLOR', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (137, 'DARLENE', 'THOMAS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (138, 'DEBORAH', 'THOMPSON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (139, 'TAMMIE', 'THOMPSON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (140, 'CHARLOTTE', 'TITUS', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (141, 'DEBBIE', 'UNDERHILL', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (142, 'RALPH', 'VOGEL', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (143, 'KATHRYN', 'WAINSCOTT', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (144, 'TONYA', 'WALLACE', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (145, 'STACEY', 'WEAVER', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (146, 'IVAN', 'WEINSTEIN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (147, 'MARIE', 'WESTBROOK', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (148, 'WILLIAM', 'WHELAN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (149, 'GEORGE', 'WILCOX', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (150, 'ESSIE', 'WILKES-SCOTT', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (151, 'ELISABETH', 'WILSON', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (152, 'CINDY', 'WOLLOCH', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (153, 'SAM', 'WUNDER', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (154, 'JANET', 'YATES', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (155, 'JOAN', 'ZAFFARANO', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (156, 'AZZA', 'ZAKI', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (157, 'SUSAN', 'ZAPOTOCZNY', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (158, 'DAVE', 'WHITTEN', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (159, 'ECA-IIP', 'EX', 'pass', 'email', 'A', 2);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (160, 'RODNEY', 'ADAMS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (161, 'ELIZABETH', 'ADGERSON', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (162, 'MANUEL', 'AGROMAYOR', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (163, 'SAMUEL', 'ANDERSON', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (164, 'CARLOS', 'ARANAGA', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (165, 'WILLIAM', 'BACH', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (166, 'ESTELLE', 'BAIRD', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (167, 'MICHAEL', 'BANDLER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (168, 'STACEY ROSE', 'BLASS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (169, 'MARY', 'BOONE', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (170, 'ZELMA', 'BRIGGS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (171, 'GEORGE', 'BROWN', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (172, 'SANDRA', 'BRUCKNER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (173, 'MARY NELL', 'BRYANT', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (174, 'LORRETA', 'BUSH', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (175, 'BRENDA', 'BUTLER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (176, 'MIRIAM', 'CARVELLA', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (177, 'JEAN', 'CAVANAUGH', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (178, 'GRETCHEN', 'CHRISTISON', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (179, 'GEORGE', 'CLACK', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (180, 'DARRELL', 'COCHRAN', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (181, 'CHARLES', 'COREY', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (182, 'ELIZABETH', 'CRAIG-DAVIS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (183, 'RALPH', 'DANNHEISSER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (184, 'SUZANNE', 'DAWKINS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (185, 'EILEEN', 'DEEGAN', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (186, 'MARTHA', 'DEUTSCHER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (187, 'FLORENCE', 'DOUGLAS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (188, 'TOM', 'EICHLER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (189, 'SUSAN', 'ELLIS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (190, 'MONA', 'ESQUENTINI', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (191, 'PATRICIA', 'FAUNCE', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (192, 'WILLIAM', 'DURHAM', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (193, 'LOUISE', 'FENNER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (194, 'JAMES', 'FISCHER-THOMPSON', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (195, 'BARRY', 'FITZGERALD', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (196, 'JAMES', 'FULLER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (197, 'STUART', 'GAMBLE', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (198, 'LAURA', 'GOULD', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (199, 'ANITA', 'GREEN', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (200, 'KATHRYN', 'GUNNING', 'pass', 'email', 'A', 3);
commit;
prompt 200 records committed...
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (201, 'WAYNE', 'HALL', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (202, 'RICHARD', 'HARMAN', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (203, 'CHAS', 'HAUSHEER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (204, 'ALFRED', 'HEAD', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (205, 'JOE', 'HOCKERSMITH', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (206, 'SELINA', 'HOLT', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (207, 'HUGH', 'HOWARD', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (208, 'PEGGY', 'HU', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (209, 'KATHLEEN', 'HUG', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (210, 'KEVIN', 'HUNTER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (211, 'DOLORES', 'HYLANDER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (212, 'DEBORAH', 'JACKSON', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (213, 'CHRISTINE', 'JOHNSON', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (214, 'MERLE', 'KELLERHALS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (215, 'DAVID', 'KRAMER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (216, 'CYNTHIA', 'LACOVEY', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (217, 'STEPHEN', 'LAROCQUE', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (218, 'BARBARA', 'LONG', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (219, 'THAN', 'LWIN', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (220, 'PAUL', 'MALAMUD', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (221, 'MARTIN', 'MANNING', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (222, 'STUART', 'MAZER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (223, 'ANDREA', 'MCGLINCHEY', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (224, 'MARGARET', 'MCKAY', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (225, 'JAMIE', 'METZEL', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (226, 'THADDEUS', 'MIKSINSKI', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (227, 'LA SEANE', 'MILLER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (228, 'AFAF', 'MITCHELL', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (229, 'LAUREN', 'MONSEN', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (230, 'KEVIN', 'MORAN', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (232, 'MILDRED', 'NEELY', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (233, 'RANDA', 'NOUR', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (234, 'BRUCE', 'ODESSEY', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (235, 'JANINE', 'PERRY', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (236, 'NORMAN', 'PHILLIPS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (237, 'ROSELYNE', 'PLACE', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (238, 'LUANNE', 'POND', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (239, 'CHARLENE', 'PORTER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (240, 'STEVE', 'PRIETO', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (241, 'WILLIAM', 'REINCKENS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (242, 'WARNER', 'ROSE', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (243, 'HELEN', 'ROUCE', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (244, 'AMOR', 'SAFI', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (245, 'ANTHONY', 'SARITI', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (246, 'JONATHAN', 'SCHAFFER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (247, 'SYLVIA', 'SCOTT', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (248, 'HELEN', 'SEBSOW', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (249, 'YVONNE', 'SHANKS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (250, 'JUDITH', 'SIEGEL', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (251, 'JANELLE', 'SIMMONS, JANELLE', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (252, 'MICHELE', 'SSMITH', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (253, 'CHUCK', 'SPEORL', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (254, 'CRAIG', 'SPRINGER', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (255, 'GLORIA', 'STEELE', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (256, 'ILYA', 'SUSLOV', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (257, 'ROSALIE', 'TARGONSKI', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (258, 'JEFFREY', 'THOMAS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (259, 'ELLEN', 'TOOMEY', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (260, 'JUDITH', 'TRUNZO', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (261, 'LORAINE', 'VENEY', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (262, 'KAREN', 'WAKEFILED', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (263, 'WILLIAM', 'WANLUND', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (264, 'DIANE', 'WATSON', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (265, 'DENA', 'WEINSTEIN', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (266, 'JOHN', 'WICART', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (267, 'DIANA', 'WILLIAMS', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (268, 'LEONARDO', 'WILLIAMS ', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (269, 'KATE', 'YEMELANOV', 'pass', 'email', 'A', 3);
insert into USERS (IDS, FNAME, LNAME, PASS, EMAIL, ACT_INACT, ORG_ID)
values (270, 'DAVID', 'ZWEIGEL', 'pass', 'email', 'A', 3);
commit;

alter table USERS enable all triggers;

